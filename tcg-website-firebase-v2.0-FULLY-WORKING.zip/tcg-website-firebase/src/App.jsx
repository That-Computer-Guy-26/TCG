import React, { useState, useRef, useEffect } from 'react';
import { Menu, X, Send, MessageSquare, BarChart3, Settings, LogOut } from 'lucide-react';
import ChatWidget from './components/ChatWidget';
import ServicesShowcase from './components/ServicesShowcase';
import BookingForm from './components/BookingForm';
import AdminDashboard from './components/AdminDashboard';
import './App.css';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [selectedApp, setSelectedApp] = useState(null); // For apps

  const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3000';

  const handleAdminLogin = () => {
    // In production, implement proper auth
    if (adminPassword === 'tcg2026admin') {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setAdminPassword('');
    } else {
      alert('Invalid password');
    }
  };

  const handleAdminLogout = () => {
    setIsAdmin(false);
  };

  return (
    <div className="app">
      {/* HEADER */}
      <header className="header">
        <div className="container header-content">
          <div className="logo">
            <h1>TCG</h1>
            <p>That Computer Guy</p>
          </div>

          {/* DESKTOP NAV */}
          <nav className="nav desktop-nav">
            <a href="#" onClick={() => setActiveTab('home')} className={activeTab === 'home' ? 'active' : ''}>
              Home
            </a>
            <a href="#" onClick={() => setActiveTab('services')} className={activeTab === 'services' ? 'active' : ''}>
              Services
            </a>
            <a href="#" onClick={() => setActiveTab('booking')} className={activeTab === 'booking' ? 'active' : ''}>
              Book Service
            </a>
            <a href="#" onClick={() => setActiveTab('chat')} className={activeTab === 'chat' ? 'active' : ''}>
              <MessageSquare size={16} /> Chat
            </a>
            <a href="#" onClick={() => setActiveTab('apps')} className={activeTab === 'apps' ? 'active' : ''}>
              🚀 Apps
            </a>
            <button className="btn btn-purple btn-sm" onClick={() => setShowAdminLogin(true)}>
              <BarChart3 size={14} /> Admin
            </button>
          </nav>

          {/* MOBILE MENU TOGGLE */}
          <button className="mobile-menu-btn" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* MOBILE NAV */}
        {mobileMenuOpen && (
          <nav className="mobile-nav">
            <a href="#" onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }}>Home</a>
            <a href="#" onClick={() => { setActiveTab('services'); setMobileMenuOpen(false); }}>Services</a>
            <a href="#" onClick={() => { setActiveTab('booking'); setMobileMenuOpen(false); }}>Book Service</a>
            <a href="#" onClick={() => { setActiveTab('chat'); setMobileMenuOpen(false); }}>Chat</a>
            <a href="#" onClick={() => { setActiveTab('apps'); setMobileMenuOpen(false); }}>🚀 Apps</a>
            <button className="btn btn-purple btn-full" onClick={() => setShowAdminLogin(true)}>Admin</button>
          </nav>
        )}
      </header>

      {/* ADMIN LOGIN MODAL */}
      {showAdminLogin && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Admin Login</h3>
              <button className="close-btn" onClick={() => { setShowAdminLogin(false); setAdminPassword(''); }}>×</button>
            </div>
            <div className="modal-body">
              <label className="label">Password</label>
              <input
                type="password"
                className="input"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Enter admin password"
                onKeyDown={(e) => e.key === 'Enter' && handleAdminLogin()}
              />
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={() => { setShowAdminLogin(false); setAdminPassword(''); }}>Cancel</button>
              <button className="btn btn-primary" onClick={handleAdminLogin}>Login</button>
            </div>
          </div>
        </div>
      )}

      {/* MAIN CONTENT */}
      <main className="main-content">
        {isAdmin ? (
          <AdminDashboard apiBase={API_BASE} onLogout={handleAdminLogout} />
        ) : (
          <>
            {activeTab === 'home' && <HomeScreen apiBase={API_BASE} onChat={() => setActiveTab('chat')} onApps={() => setActiveTab('apps')} />}
            {activeTab === 'services' && <ServicesShowcase />}
            {activeTab === 'chat' && <ChatWidget apiBase={API_BASE} context="customer" />}
            {activeTab === 'booking' && <BookingForm apiBase={API_BASE} />}
            {activeTab === 'apps' && <AppsPortal />}
          </>
        )}
      </main>

      {/* FOOTER */}
      <footer className="footer">
        <div className="container">
          <div className="footer-content">
            <div className="footer-section">
              <h4>That Computer Guy</h4>
              <p>Gary Amick — IT Support & AI Automation</p>
              <p>Seymour, Indiana</p>
            </div>
            <div className="footer-section">
              <h4>Contact</h4>
              <p>📞 (812) 373-6023</p>
              <p>📧 gary.amick0614@gmail.com</p>
              <p>💬 Chat here for quick answers</p>
            </div>
            <div className="footer-section">
              <h4>Quick Links</h4>
              <p>Computer Repair | Networking | AI Automation</p>
              <p>Web Development | Security | Data Recovery</p>
              <p>Promo: TCG26FREE (first-time customers)</p>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2026 That Computer Guy. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// HOME SCREEN COMPONENT
function HomeScreen({ apiBase, onChat }) {
  return (
    <section className="home-screen">
      <div className="hero">
        <div className="container">
          <h1 className="hero-title">That Computer Guy 26</h1>
          <p className="hero-subtitle">Professional IT Support & AI Automation for Seymour, Indiana</p>
          <div className="hero-buttons">
            <button className="btn btn-primary btn-lg" onClick={onChat}>
              <MessageSquare size={18} /> Start Chat
            </button>
            <a href="#" onClick={() => document.querySelector('.hero').scrollIntoView()} className="btn btn-ghost btn-lg">
              Learn More
            </a>
          </div>
        </div>
      </div>

      <div className="container">
        <section className="features">
          <h2>What We Offer</h2>
          <div className="grid grid-3">
            <div className="card">
              <h3>💻 Computer Repair</h3>
              <p>Virus removal, OS installation, hardware diagnostics, data recovery, upgrades, and optimization.</p>
            </div>
            <div className="card">
              <h3>🤖 AI & Automation</h3>
              <p>ChatGPT setup, custom AI assistants, workflow automation, business process optimization.</p>
            </div>
            <div className="card">
              <h3>🔒 Security & Protection</h3>
              <p>Antivirus installation, firewall setup, password management, security audits, ransomware protection.</p>
            </div>
            <div className="card">
              <h3>🌐 Networking</h3>
              <p>WiFi setup, router configuration, network security, VPN setup, IP camera installation.</p>
            </div>
            <div className="card">
              <h3>🛠️ Custom Development</h3>
              <p>Website development, web apps, databases, API integration, React/Node applications.</p>
            </div>
            <div className="card">
              <h3>📱 Mobile & Devices</h3>
              <p>Phone repair, tablet setup, data transfer, phone optimization, device troubleshooting.</p>
            </div>
          </div>
        </section>

        <section className="pricing">
          <h2>Transparent Pricing</h2>
          <div className="grid grid-4">
            <div className="price-card">
              <h3>Remote Basic</h3>
              <div className="price">$35/hr</div>
              <p>Remote support and troubleshooting</p>
            </div>
            <div className="price-card">
              <h3>On-Site Standard</h3>
              <div className="price">$55/hr</div>
              <p>Local repair and installation</p>
            </div>
            <div className="price-card">
              <h3>Business Pro</h3>
              <div className="price">$75/hr</div>
              <p>Business solutions and consulting</p>
            </div>
            <div className="price-card">
              <h3>Emergency 24/7</h3>
              <div className="price">$95/hr</div>
              <p>Priority emergency support</p>
            </div>
          </div>
          <div className="promo-banner">
            <strong>🎉 Promo Code: TCG26FREE</strong> — First-time customers get special discount
          </div>
        </section>

        <section className="apps-promo">
          <h2>🚀 Quick Apps</h2>
          <p>Integrated business management tools</p>
          <div className="apps-quick">
            <div className="quick-app-card" onClick={() => onApps()}>
              <div className="quick-icon">💕</div>
              <div className="quick-info">
                <h4>Nevaeh Family App</h4>
                <p>Family & financial management</p>
              </div>
              <span className="arrow">→</span>
            </div>
          </div>
        </section>

        <section className="free-services">
          <h2>Free Services For</h2>
          <div className="free-list">
            <span>✓ Addiction Recovery Foundations</span>
            <span>✓ Active Recovery Individuals</span>
            <span>✓ Emergency Services (Fire, EMS)</span>
            <span>✓ Law Enforcement</span>
            <span>✓ Re-Entry Services</span>
            <span>✓ Religious Organizations</span>
            <span>✓ Mental Health Organizations</span>
            <span>✓ Suicide Prevention Organizations</span>
          </div>
        </section>
      </div>
    </section>
  );
}

// APPS PORTAL COMPONENT
function AppsPortal() {
  const [selectedApp, setSelectedApp] = useState(null);

  const apps = [
    {
      id: 'nevaeh',
      name: '💕 Nevaeh Family App',
      description: 'Family management dashboard - finances, events, members',
      version: 'v7.0',
      url: '/nevaeh-family-app.html',
      category: 'Family',
      icon: '👨‍👩‍👧‍👦'
    }
  ];

  if (selectedApp) {
    return (
      <div className="apps-viewer">
        <div className="container">
          <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2>{selectedApp.name}</h2>
            <button className="btn btn-ghost btn-sm" onClick={() => setSelectedApp(null)}>← Back to Apps</button>
          </div>
          <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', height: '80vh' }}>
            <iframe
              src={selectedApp.url}
              style={{ width: '100%', height: '100%', border: 'none' }}
              title={selectedApp.name}
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-modals"
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="apps-portal">
      <div className="container">
        <h1 className="page-title">🚀 Apps & Tools</h1>
        <p className="page-subtitle">Integrated business and family management applications</p>

        <div className="apps-grid">
          {apps.map((app) => (
            <div key={app.id} className="app-card" onClick={() => setSelectedApp(app)}>
              <div className="app-icon">{app.icon}</div>
              <h3>{app.name}</h3>
              <p className="app-desc">{app.description}</p>
              <div className="app-footer">
                <span className="app-category">{app.category}</span>
                <span className="app-version">{app.version}</span>
              </div>
              <button className="btn btn-primary" style={{ width: '100%', marginTop: '12px' }}>
                Open App →
              </button>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        .apps-portal {
          padding: 40px 20px;
        }

        .page-title {
          font-size: 36px;
          font-weight: 900;
          text-align: center;
          margin-bottom: 12px;
        }

        .page-subtitle {
          font-size: 16px;
          color: var(--muted);
          text-align: center;
          margin-bottom: 40px;
        }

        .apps-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 20px;
        }

        .app-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 24px;
          cursor: pointer;
          transition: all 0.3s;
          display: flex;
          flex-direction: column;
        }

        .app-card:hover {
          border-color: rgba(0, 212, 255, 0.5);
          box-shadow: 0 8px 30px rgba(0, 212, 255, 0.1);
          transform: translateY(-4px);
        }

        .app-icon {
          font-size: 48px;
          margin-bottom: 16px;
        }

        .app-card h3 {
          font-size: 18px;
          margin-bottom: 8px;
          color: var(--text);
        }

        .app-desc {
          font-size: 13px;
          color: var(--muted);
          margin-bottom: 16px;
          flex: 1;
        }

        .app-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 11px;
          margin-bottom: 12px;
          padding-top: 12px;
          border-top: 1px solid var(--border);
        }

        .app-category {
          background: rgba(0, 212, 255, 0.15);
          color: var(--cyan);
          padding: 4px 8px;
          border-radius: 4px;
          text-transform: uppercase;
          font-weight: 600;
        }

        .app-version {
          color: var(--muted);
          font-family: 'Courier New', monospace;
        }

        .apps-viewer {
          padding: 20px;
        }

        .apps-viewer .container {
          max-width: 1400px;
        }

        @media (max-width: 768px) {
          .apps-grid {
            grid-template-columns: 1fr;
          }

          .page-title {
            font-size: 24px;
          }

          .apps-viewer {
            padding: 12px;
          }
        }
      `}</style>
    </div>
  );
}
