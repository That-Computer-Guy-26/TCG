import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader } from 'lucide-react';

export default function ChatWidget({ apiBase, context = 'customer', agentId = 'ORCH-001' }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [provider, setProvider] = useState('unknown');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = { role: 'user', content: input };
    setMessages([...messages, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch(`${apiBase}/api/ai-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: input,
          context,
          history: messages,
          agent_id: agentId,
        }),
      });

      const data = await response.json();
      if (data.error) {
        setMessages(prev => [...prev, { role: 'assistant', content: `Error: ${data.error}` }]);
      } else {
        setMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
        setProvider(data.provider);
      }
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: `Connection error: ${error.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="chat-widget">
      <div className="container" style={{ maxWidth: '800px' }}>
        <div className="chat-container">
          <div className="chat-header">
            <h2>💬 Chat with TCG AI</h2>
            <p className="chat-subtitle">
              Get instant answers about our services
              {provider && <span className="provider-badge">{provider}</span>}
            </p>
          </div>

          <div className="chat-messages">
            {messages.length === 0 && (
              <div className="chat-empty">
                <h3>👋 Welcome to TCG Chat</h3>
                <p>Ask questions about:</p>
                <ul>
                  <li>Computer repair services</li>
                  <li>Pricing and availability</li>
                  <li>AI automation solutions</li>
                  <li>Network setup and security</li>
                  <li>Booking appointments</li>
                </ul>
                <p className="mt-20" style={{ fontSize: '12px', color: 'var(--muted)' }}>
                  Powered by rotating AI models (Ollama, LM Studio, Groq, Together.ai)
                </p>
              </div>
            )}

            {messages.map((msg, idx) => (
              <div key={idx} className={`chat-message ${msg.role}`}>
                <div className="message-content">
                  <p>{msg.content}</p>
                </div>
              </div>
            ))}

            {loading && (
              <div className="chat-message assistant">
                <div className="message-content loading-message">
                  <Loader size={16} className="spinner" style={{ marginRight: '8px' }} />
                  Thinking...
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSend} className="chat-form">
            <input
              type="text"
              className="input"
              placeholder="Ask a question..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={loading}
            />
            <button type="submit" className="btn btn-primary" disabled={loading}>
              <Send size={16} />
            </button>
          </form>
        </div>
      </div>

      <style>{`
        .chat-widget {
          padding: 40px 20px;
          background: linear-gradient(135deg, rgba(0, 212, 255, 0.05), rgba(168, 85, 247, 0.05));
          min-height: 600px;
        }

        .chat-container {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          display: flex;
          flex-direction: column;
          height: 600px;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }

        .chat-header {
          padding: 20px;
          border-bottom: 1px solid var(--border);
          background: linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(168, 85, 247, 0.1));
        }

        .chat-header h2 {
          margin-bottom: 4px;
          font-size: 18px;
        }

        .chat-subtitle {
          font-size: 13px;
          color: var(--muted);
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .provider-badge {
          background: rgba(0, 212, 255, 0.2);
          color: var(--cyan);
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
        }

        .chat-messages {
          flex: 1;
          overflow-y: auto;
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .chat-empty {
          text-align: center;
          margin: auto;
          color: var(--muted);
        }

        .chat-empty h3 {
          font-size: 18px;
          color: var(--text);
          margin-bottom: 12px;
        }

        .chat-empty ul {
          list-style: none;
          margin: 12px 0;
        }

        .chat-empty li {
          padding: 4px 0;
          font-size: 13px;
        }

        .chat-message {
          display: flex;
          margin-bottom: 8px;
        }

        .chat-message.user {
          justify-content: flex-end;
        }

        .chat-message.assistant {
          justify-content: flex-start;
        }

        .message-content {
          background: var(--bg3);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 12px 16px;
          max-width: 70%;
          word-wrap: break-word;
          font-size: 13px;
          line-height: 1.6;
        }

        .chat-message.user .message-content {
          background: linear-gradient(135deg, rgba(0, 212, 255, 0.2), rgba(59, 130, 246, 0.2));
          border-color: rgba(0, 212, 255, 0.3);
          color: var(--text);
        }

        .chat-message.assistant .message-content {
          background: var(--bg3);
          border-color: var(--border);
          color: var(--muted);
        }

        .loading-message {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .chat-form {
          display: flex;
          gap: 8px;
          padding: 16px;
          border-top: 1px solid var(--border);
        }

        .chat-form input {
          flex: 1;
        }

        .chat-form button {
          padding: 10px 16px;
        }

        @media (max-width: 768px) {
          .chat-container {
            height: 500px;
          }

          .message-content {
            max-width: 85%;
          }
        }
      `}</style>
    </div>
  );
}
