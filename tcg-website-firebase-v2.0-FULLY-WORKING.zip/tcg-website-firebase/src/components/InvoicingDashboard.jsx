import React, { useState, useEffect } from 'react';
import { Plus, Send, Download, Filter, Search } from 'lucide-react';

export default function InvoicingDashboard({ apiBase }) {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewInvoice, setShowNewInvoice] = useState(false);

  useEffect(() => {
    loadInvoices();
  }, []);

  const loadInvoices = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/api/invoices`);
      const data = await res.json();
      setInvoices(data.invoices || []);
    } catch (e) {
      console.error('Failed to load invoices:', e);
    } finally {
      setLoading(false);
    }
  };

  const filteredInvoices = invoices.filter(inv => {
    if (filter !== 'all' && inv.status !== filter) return false;
    if (searchTerm && !inv.id.includes(searchTerm) && !inv.customer_id.includes(searchTerm)) return false;
    return true;
  });

  const stats = {
    total: invoices.length,
    pending: invoices.filter(i => i.status === 'draft' || i.status === 'sent').length,
    paid: invoices.filter(i => i.status === 'paid').length,
    overdue: invoices.filter(i => new Date(i.due_date) < new Date() && i.status !== 'paid').length,
    revenue: invoices.filter(i => i.status === 'paid').reduce((sum, i) => sum + i.total, 0)
  };

  return (
    <div className="invoicing-dashboard">
      <div style={{ marginBottom: '32px' }}>
        <h2 style={{ marginBottom: '24px' }}>💳 Invoicing Management</h2>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px', marginBottom: '32px' }}>
          <StatCard label="Total Invoices" value={stats.total} />
          <StatCard label="Pending" value={stats.pending} color="orange" />
          <StatCard label="Paid" value={stats.paid} color="green" />
          <StatCard label="Overdue" value={stats.overdue} color="red" />
          <StatCard label="Total Revenue" value={`$${stats.revenue.toFixed(2)}`} color="cyan" />
        </div>

        {/* Controls */}
        <div style={{ display: 'flex', gap: '12px', marginBottom: '20px', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '200px', position: 'relative' }}>
            <Search size={16} style={{ position: 'absolute', left: '12px', top: '12px', opacity: 0.5 }} />
            <input
              type="text"
              className="input"
              placeholder="Search invoices..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ paddingLeft: '36px' }}
            />
          </div>
          <select className="input" value={filter} onChange={(e) => setFilter(e.target.value)} style={{ minWidth: '150px' }}>
            <option value="all">All Invoices</option>
            <option value="draft">Draft</option>
            <option value="sent">Sent</option>
            <option value="paid">Paid</option>
            <option value="overdue">Overdue</option>
          </select>
          <button className="btn btn-primary" onClick={() => setShowNewInvoice(true)}>
            <Plus size={16} /> New Invoice
          </button>
        </div>

        {/* Invoices Table */}
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%' }}>
            <thead>
              <tr>
                <th>Invoice ID</th>
                <th>Customer</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((inv) => (
                <tr key={inv.id}>
                  <td><strong>{inv.id}</strong></td>
                  <td>{inv.customer_id}</td>
                  <td>${inv.total.toFixed(2)}</td>
                  <td><span className={`badge badge-${inv.status}`}>{inv.status}</span></td>
                  <td>{new Date(inv.due_date).toLocaleDateString()}</td>
                  <td>
                    <button className="btn btn-sm btn-primary" title="Send Invoice">
                      <Send size={14} />
                    </button>
                    <button className="btn btn-sm btn-ghost" title="Download PDF">
                      <Download size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <style>{`
        .invoicing-dashboard {
          padding: 20px;
        }

        .stat-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 16px;
          text-align: center;
        }

        .stat-value {
          font-size: 28px;
          font-weight: 800;
          margin: 8px 0;
        }

        .stat-label {
          font-size: 12px;
          color: var(--muted);
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .badge-draft { background: rgba(100, 116, 139, 0.2); color: var(--muted); }
        .badge-sent { background: rgba(59, 130, 246, 0.2); color: var(--blue); }
        .badge-paid { background: rgba(34, 197, 94, 0.2); color: var(--green); }
        .badge-overdue { background: rgba(239, 68, 68, 0.2); color: var(--red); }
      `}</style>
    </div>
  );
}

function StatCard({ label, value, color }) {
  const colors = {
    cyan: '#00d4ff',
    green: '#22c55e',
    red: '#ef4444',
    orange: '#f97316',
    default: '#3b82f6'
  };

  return (
    <div className="stat-card">
      <div className="stat-label">{label}</div>
      <div className="stat-value" style={{ color: colors[color] || colors.default }}>
        {value}
      </div>
    </div>
  );
}
