import React, { useState, useEffect } from 'react';
import { LogOut, BarChart3, Mail, Calendar, DollarSign, MessageSquare, Settings, Loader, Users, TrendingUp, Clock, Package } from 'lucide-react';
import ChatWidget from './ChatWidget';
import InvoicingDashboard from './InvoicingDashboard';
import SchedulingDashboard from './SchedulingDashboard';
import CRMDashboard from './CRMDashboard';
import ReportsDashboard from './ReportsDashboard';
import TimeTrackingDashboard from './TimeTrackingDashboard';
import InventoryDashboard from './InventoryDashboard';

export default function AdminDashboard({ apiBase, onLogout }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [data, setData] = useState({
    bookings: [],
    leads: [],
    conversations: [],
    customers: []
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const collections = ['bookings', 'leads', 'conversations', 'customers'];
      const results = {};

      for (const col of collections) {
        try {
          const res = await fetch(`${apiBase}/api/data/${col}`);
          const json = await res.json();
          results[col] = json.items || [];
        } catch (e) {
          console.warn(`Failed to load ${col}:`, e);
          results[col] = [];
        }
      }

      setData(results);
    } catch (e) {
      console.error('Failed to load dashboard data:', e);
    } finally {
      setLoading(false);
    }
  };

  const stats = {
    bookings: data.bookings.length,
    leads: data.leads.length,
    conversations: data.conversations.length,
    customers: data.customers.length
  };

  return (
    <div className="admin-dashboard">
      {/* ADMIN HEADER */}
      <div className="admin-header">
        <div className="container">
          <div className="admin-title">
            <BarChart3 size={28} />
            <h1>TCG Admin Dashboard</h1>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={onLogout}>
            <LogOut size={14} /> Logout
          </button>
        </div>
      </div>

      {/* TABS */}
      <div className="admin-tabs">
        <div className="container">
          <div className="tabs-scroll">
            <button
              className={`admin-tab ${activeTab === 'overview' ? 'active' : ''}`}
              onClick={() => setActiveTab('overview')}
            >
              <BarChart3 size={16} /> Overview
            </button>
            <button
              className={`admin-tab ${activeTab === 'bookings' ? 'active' : ''}`}
              onClick={() => setActiveTab('bookings')}
            >
              <Calendar size={16} /> Bookings
            </button>
            <button
              className={`admin-tab ${activeTab === 'leads' ? 'active' : ''}`}
              onClick={() => setActiveTab('leads')}
            >
              <Mail size={16} /> Leads
            </button>
            <button
              className={`admin-tab ${activeTab === 'invoicing' ? 'active' : ''}`}
              onClick={() => setActiveTab('invoicing')}
            >
              <DollarSign size={16} /> Invoicing
            </button>
            <button
              className={`admin-tab ${activeTab === 'scheduling' ? 'active' : ''}`}
              onClick={() => setActiveTab('scheduling')}
            >
              <Calendar size={16} /> Schedule
            </button>
            <button
              className={`admin-tab ${activeTab === 'crm' ? 'active' : ''}`}
              onClick={() => setActiveTab('crm')}
            >
              <Users size={16} /> CRM
            </button>
            <button
              className={`admin-tab ${activeTab === 'reports' ? 'active' : ''}`}
              onClick={() => setActiveTab('reports')}
            >
              <TrendingUp size={16} /> Reports
            </button>
            <button
              className={`admin-tab ${activeTab === 'timekeeping' ? 'active' : ''}`}
              onClick={() => setActiveTab('timekeeping')}
            >
              <Clock size={16} /> Time Track
            </button>
            <button
              className={`admin-tab ${activeTab === 'inventory' ? 'active' : ''}`}
              onClick={() => setActiveTab('inventory')}
            >
              <Package size={16} /> Inventory
            </button>
            <button
              className={`admin-tab ${activeTab === 'chat' ? 'active' : ''}`}
              onClick={() => setActiveTab('chat')}
            >
              <MessageSquare size={16} /> Chat
            </button>
          </div>
        </div>
      </div>

      {/* CONTENT */}
      <div className="admin-content">
        <div className="container">
          {loading && (
            <div className="loading-state">
              <Loader size={32} className="spinner" />
              <p>Loading data...</p>
            </div>
          )}

          {!loading && activeTab === 'overview' && (
            <OverviewTab stats={stats} data={data} />
          )}

          {!loading && activeTab === 'bookings' && (
            <BookingsTab bookings={data.bookings} apiBase={apiBase} />
          )}

          {!loading && activeTab === 'leads' && (
            <LeadsTab leads={data.leads} apiBase={apiBase} />
          )}

          {!loading && activeTab === 'invoicing' && (
            <InvoicingDashboard apiBase={apiBase} />
          )}

          {!loading && activeTab === 'scheduling' && (
            <SchedulingDashboard apiBase={apiBase} />
          )}

          {!loading && activeTab === 'crm' && (
            <CRMDashboard apiBase={apiBase} />
          )}

          {!loading && activeTab === 'reports' && (
            <ReportsDashboard apiBase={apiBase} />
          )}

          {!loading && activeTab === 'timekeeping' && (
            <TimeTrackingDashboard apiBase={apiBase} />
          )}

          {!loading && activeTab === 'inventory' && (
            <InventoryDashboard apiBase={apiBase} />
          )}

          {!loading && activeTab === 'chat' && (
            <ChatWidget apiBase={apiBase} context="admin" agentId="ORCH-001" />
          )}
        </div>
      </div>

      <style>{`
        .admin-dashboard {
          flex: 1;
          background: var(--bg);
        }

        .admin-header {
          background: linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(168, 85, 247, 0.1));
          border-bottom: 1px solid var(--border);
          padding: 20px 0;
          margin-bottom: 20px;
        }

        .admin-header .container {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .admin-title {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .admin-title h1 {
          font-size: 24px;
          font-weight: 700;
        }

        .admin-tabs {
          background: var(--bg2);
          border-bottom: 1px solid var(--border);
          position: sticky;
          top: 60px;
          z-index: 50;
        }

        .admin-tabs .container {
          display: flex;
          gap: 0;
          overflow-x: auto;
        }

        .admin-tab {
          background: none;
          border: none;
          color: var(--muted);
          padding: 16px 20px;
          font-weight: 600;
          font-size: 14px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 6px;
          border-bottom: 2px solid transparent;
          transition: all 0.2s;
          white-space: nowrap;
        }

        .admin-tab:hover {
          color: var(--text);
        }

        .admin-tab.active {
          color: var(--cyan);
          border-bottom-color: var(--cyan);
        }

        .admin-content {
          padding: 40px 20px;
        }

        .loading-state {
          text-align: center;
          padding: 60px 20px;
        }

        .loading-state .spinner {
          margin-bottom: 16px;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 16px;
          margin-bottom: 40px;
        }

        .stat-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .stat-value {
          font-size: 32px;
          font-weight: 800;
          color: var(--cyan);
        }

        .stat-label {
          font-size: 13px;
          color: var(--muted);
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .table-container {
          overflow-x: auto;
          margin-top: 20px;
        }

        table {
          width: 100%;
          border-collapse: collapse;
        }

        th {
          text-align: left;
          padding: 12px;
          background: var(--bg3);
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          color: var(--muted);
          border-bottom: 1px solid var(--border);
        }

        td {
          padding: 12px;
          border-bottom: 1px solid var(--border);
          font-size: 13px;
        }

        tr:hover {
          background: rgba(0, 212, 255, 0.05);
        }

        .status-badge {
          display: inline-block;
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
        }

        .status-new {
          background: rgba(0, 212, 255, 0.2);
          color: var(--cyan);
        }

        .status-confirmed {
          background: rgba(34, 197, 94, 0.2);
          color: var(--green);
        }

        .status-completed {
          background: rgba(107, 114, 128, 0.2);
          color: var(--muted);
        }
      `}</style>
    </div>
  );
}

function OverviewTab({ stats, data }) {
  return (
    <div>
      <h2 style={{ marginBottom: '32px' }}>Dashboard Overview</h2>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-value">{stats.bookings}</div>
          <div className="stat-label">Total Bookings</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.leads}</div>
          <div className="stat-label">Contact Leads</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.conversations}</div>
          <div className="stat-label">Chat Conversations</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.customers}</div>
          <div className="stat-label">Total Customers</div>
        </div>
      </div>

      <div className="card">
        <h3>📊 Recent Activity</h3>
        <p style={{ marginTop: '12px', color: 'var(--muted)', fontSize: '13px' }}>
          View bookings, leads, and conversations in their respective tabs. Click the refresh button to update data.
        </p>
      </div>
    </div>
  );
}

function BookingsTab({ bookings, apiBase }) {
  return (
    <div>
      <h2 style={{ marginBottom: '32px' }}>Appointments & Bookings</h2>

      {bookings.length === 0 ? (
        <div className="card">
          <p style={{ textAlign: 'center', color: 'var(--muted)' }}>No bookings yet</p>
        </div>
      ) : (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Service</th>
                <th>Date</th>
                <th>Status</th>
                <th>Contact</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking, idx) => (
                <tr key={idx}>
                  <td>{booking.name}</td>
                  <td>{booking.service}</td>
                  <td>{booking.date || 'TBD'}</td>
                  <td>
                    <span className={`status-badge status-${booking.status || 'new'}`}>
                      {booking.status || 'new'}
                    </span>
                  </td>
                  <td>{booking.email}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function LeadsTab({ leads, apiBase }) {
  return (
    <div>
      <h2 style={{ marginBottom: '32px' }}>Contact Leads</h2>

      {leads.length === 0 ? (
        <div className="card">
          <p style={{ textAlign: 'center', color: 'var(--muted)' }}>No leads yet</p>
        </div>
      ) : (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Service</th>
                <th>Message</th>
                <th>Status</th>
                <th>Contact</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((lead, idx) => (
                <tr key={idx}>
                  <td>{lead.name}</td>
                  <td>{lead.service}</td>
                  <td style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {lead.message}
                  </td>
                  <td>
                    <span className={`status-badge status-${lead.status || 'new'}`}>
                      {lead.status || 'new'}
                    </span>
                  </td>
                  <td>{lead.email}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
