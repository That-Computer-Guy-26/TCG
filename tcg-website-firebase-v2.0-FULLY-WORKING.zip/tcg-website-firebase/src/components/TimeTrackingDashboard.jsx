import React, { useState, useEffect } from 'react';
import { Clock, Play, StopCircle, User, DollarSign, Calendar } from 'lucide-react';

export default function TimeTrackingDashboard({ apiBase }) {
  const [sessions, setSessions] = useState([]);
  const [technicians, setTechnicians] = useState([]);
  const [activeSession, setActiveSession] = useState(null);
  const [selectedTech, setSelectedTech] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const techRes = await fetch(`${apiBase}/api/data/technicians`);
      const techData = await techRes.json();
      setTechnicians(techData.items || []);

      if (selectedTech) {
        const sessRes = await fetch(`${apiBase}/api/timekeeping/technician/${selectedTech}`);
        const sessData = await sessRes.json();
        setSessions(sessData.sessions || []);
      }
    } catch (e) {
      console.error('Failed to load data:', e);
    } finally {
      setLoading(false);
    }
  };

  const startSession = async (techId, appointmentId) => {
    try {
      const res = await fetch(`${apiBase}/api/timekeeping/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          technician_id: techId,
          appointment_id: appointmentId,
          notes: ''
        })
      });
      const data = await res.json();
      setActiveSession(data.session);
      loadData();
    } catch (e) {
      console.error('Failed to start session:', e);
    }
  };

  const endSession = async (sessionId) => {
    try {
      const res = await fetch(`${apiBase}/api/timekeeping/${sessionId}/end`, {
        method: 'POST'
      });
      const data = await res.json();
      setActiveSession(null);
      loadData();
    } catch (e) {
      console.error('Failed to end session:', e);
    }
  };

  const totalHours = sessions.reduce((sum, s) => sum + (s.duration_minutes || 0), 0) / 60;
  const hourlyRate = 35; // $35/hour
  const totalEarnings = totalHours * hourlyRate;

  return (
    <div className="timetracking-dashboard">
      <h2 style={{ marginBottom: '24px' }}>⏱️ Time Tracking & Payroll</h2>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '32px' }}>
        <StatCard 
          icon="⏱️" 
          label="Total Hours" 
          value={totalHours.toFixed(1)} 
          subtitle="This Period"
        />
        <StatCard 
          icon="💰" 
          label="Total Earnings" 
          value={`$${totalEarnings.toFixed(2)}`}
          subtitle={`@ $${hourlyRate}/hr`}
        />
        <StatCard 
          icon="📊" 
          label="Sessions" 
          value={sessions.length}
          subtitle="Completed"
        />
      </div>

      {/* Technician Selector */}
      <div style={{ marginBottom: '24px' }}>
        <label className="label">Select Technician</label>
        <select 
          className="input"
          value={selectedTech || ''}
          onChange={(e) => {
            setSelectedTech(e.target.value);
            loadData();
          }}
        >
          <option value="">-- All Technicians --</option>
          {technicians.map((tech) => (
            <option key={tech.id} value={tech.id}>
              {tech.name}
            </option>
          ))}
        </select>
      </div>

      {/* Active Session */}
      {activeSession && (
        <div style={{
          background: 'rgba(34, 197, 94, 0.1)',
          border: '2px solid var(--green)',
          borderRadius: 'var(--radius)',
          padding: '16px',
          marginBottom: '24px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: '700', marginBottom: '4px' }}>🟢 Active Session</div>
              <div style={{ fontSize: '12px', color: 'var(--muted)' }}>
                Started: {new Date(activeSession.start_time).toLocaleTimeString()}
              </div>
            </div>
            <button 
              className="btn btn-red"
              onClick={() => endSession(activeSession.id)}
            >
              <StopCircle size={16} /> End Session
            </button>
          </div>
        </div>
      )}

      {/* Quick Start Button */}
      {!activeSession && (
        <div style={{ marginBottom: '24px' }}>
          <button 
            className="btn btn-primary"
            onClick={() => startSession(selectedTech, 'apt-001')}
          >
            <Play size={16} /> Start Work Session
          </button>
        </div>
      )}

      {/* Sessions List */}
      <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Date</th>
              <th>Start Time</th>
              <th>End Time</th>
              <th>Duration</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {sessions.map((session) => (
              <tr key={session.id}>
                <td>{new Date(session.start_time).toLocaleDateString()}</td>
                <td>{new Date(session.start_time).toLocaleTimeString()}</td>
                <td>{session.end_time ? new Date(session.end_time).toLocaleTimeString() : '-'}</td>
                <td><strong>{(session.duration_minutes / 60).toFixed(1)} hrs</strong></td>
                <td>{session.notes || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <style>{`
        .timetracking-dashboard { padding: 20px; }
        
        table {
          border-collapse: collapse;
        }

        th {
          background: var(--bg3);
          padding: 12px;
          text-align: left;
          font-weight: 600;
          font-size: 12px;
          text-transform: uppercase;
          border-bottom: 1px solid var(--border);
        }

        td {
          padding: 12px;
          border-bottom: 1px solid var(--border);
          font-size: 13px;
        }

        tr:hover {
          background: var(--bg3);
        }
      `}</style>
    </div>
  );
}

function StatCard({ icon, label, value, subtitle }) {
  return (
    <div style={{
      background: 'var(--bg2)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius)',
      padding: '16px',
      textAlign: 'center'
    }}>
      <div style={{ fontSize: '24px', marginBottom: '8px' }}>{icon}</div>
      <div style={{ fontSize: '26px', fontWeight: '800', color: 'var(--cyan)', marginBottom: '4px' }}>
        {value}
      </div>
      <div style={{ fontSize: '12px', color: 'var(--muted)', textTransform: 'uppercase' }}>
        {label}
      </div>
      {subtitle && (
        <div style={{ fontSize: '11px', color: 'var(--text2)', marginTop: '4px' }}>
          {subtitle}
        </div>
      )}
    </div>
  );
}
