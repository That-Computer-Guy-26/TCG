import React, { useState, useEffect } from 'react';
import { Users, Search, Mail, Phone, MapPin, TrendingUp } from 'lucide-react';

export default function CRMDashboard({ apiBase }) {
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/api/data/customers`);
      const data = await res.json();
      setCustomers(data.items || []);
    } catch (e) {
      console.error('Failed to load customers:', e);
    } finally {
      setLoading(false);
    }
  };

  const filteredCustomers = customers.filter(cust =>
    cust.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cust.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cust.phone?.includes(searchTerm)
  );

  const stats = {
    total: customers.length,
    active: customers.filter(c => c.status === 'active').length,
    new: customers.filter(c => {
      const created = new Date(c.created);
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      return created > thirtyDaysAgo;
    }).length
  };

  return (
    <div className="crm-dashboard">
      <h2 style={{ marginBottom: '24px' }}>👥 Customer Management (CRM)</h2>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px', marginBottom: '32px' }}>
        <StatCard label="Total Customers" value={stats.total} icon="👥" color="cyan" />
        <StatCard label="Active" value={stats.active} icon="✓" color="green" />
        <StatCard label="New (30d)" value={stats.new} icon="⭐" color="orange" />
      </div>

      {/* Search */}
      <div style={{ marginBottom: '24px', position: 'relative' }}>
        <Search size={16} style={{ position: 'absolute', left: '12px', top: '12px', opacity: 0.5 }} />
        <input
          type="text"
          className="input"
          placeholder="Search by name, email, or phone..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ paddingLeft: '36px' }}
        />
      </div>

      {/* Customers Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '16px' }}>
        {filteredCustomers.map((customer) => (
          <div key={customer.id} className="customer-card">
            <div style={{ marginBottom: '12px' }}>
              <div style={{ fontSize: '16px', fontWeight: '700', marginBottom: '4px' }}>
                {customer.name || 'Unknown'}
              </div>
              <div style={{ fontSize: '12px', color: 'var(--muted)' }}>
                ID: {customer.id}
              </div>
            </div>

            <div style={{ fontSize: '13px', lineHeight: '1.8', marginBottom: '12px' }}>
              {customer.email && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--muted)' }}>
                  <Mail size={14} />
                  <a href={`mailto:${customer.email}`} style={{ color: 'var(--cyan)' }}>
                    {customer.email}
                  </a>
                </div>
              )}
              {customer.phone && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--muted)' }}>
                  <Phone size={14} />
                  <a href={`tel:${customer.phone}`} style={{ color: 'var(--cyan)' }}>
                    {customer.phone}
                  </a>
                </div>
              )}
              {customer.address && (
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', color: 'var(--muted)' }}>
                  <MapPin size={14} style={{ marginTop: '2px', flexShrink: 0 }} />
                  <span>{customer.address}</span>
                </div>
              )}
            </div>

            <div style={{ paddingTop: '12px', borderTop: '1px solid var(--border)', fontSize: '12px', color: 'var(--muted)' }}>
              <div>Created: {new Date(customer.created).toLocaleDateString()}</div>
              {customer.status && (
                <div style={{ marginTop: '4px' }}>
                  Status: <span style={{ color: customer.status === 'active' ? 'var(--green)' : 'var(--muted)' }}>
                    {customer.status.toUpperCase()}
                  </span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <style>{`
        .crm-dashboard { padding: 20px; }
        
        .stat-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 16px;
          text-align: center;
        }

        .customer-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 16px;
          transition: all 0.2s;
          cursor: pointer;
        }

        .customer-card:hover {
          border-color: rgba(0, 212, 255, 0.5);
          box-shadow: 0 4px 12px rgba(0, 212, 255, 0.1);
          transform: translateY(-2px);
        }
      `}</style>
    </div>
  );
}

function StatCard({ label, value, icon }) {
  const colors = { cyan: '#00d4ff', green: '#22c55e', orange: '#f97316' };
  return (
    <div className="stat-card">
      <div style={{ fontSize: '24px', marginBottom: '8px' }}>{icon}</div>
      <div style={{ fontSize: '28px', fontWeight: '800', color: colors[icon] || '#00d4ff' }}>{value}</div>
      <div style={{ fontSize: '12px', color: 'var(--muted)', textTransform: 'uppercase', marginTop: '8px' }}>
        {label}
      </div>
    </div>
  );
}
