import React, { useState, useEffect } from 'react';
import { Package, AlertTriangle, Plus, Trash2, Edit2, Search } from 'lucide-react';

export default function InventoryDashboard({ apiBase }) {
  const [items, setItems] = useState([]);
  const [lowStockItems, setLowStockItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddItem, setShowAddItem] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    sku: '',
    name: '',
    quantity: 0,
    unit_cost: 0,
    supplier: '',
    reorder_level: 10
  });

  useEffect(() => {
    loadInventory();
  }, []);

  const loadInventory = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/api/data/inventory`);
      const data = await res.json();
      setItems(data.items || []);

      const lowRes = await fetch(`${apiBase}/api/inventory/low-stock`);
      const lowData = await lowRes.json();
      setLowStockItems(lowData.low_stock_items || []);
    } catch (e) {
      console.error('Failed to load inventory:', e);
    } finally {
      setLoading(false);
    }
  };

  const addItem = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`${apiBase}/api/inventory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      setFormData({ sku: '', name: '', quantity: 0, unit_cost: 0, supplier: '', reorder_level: 10 });
      setShowAddItem(false);
      loadInventory();
    } catch (e) {
      console.error('Failed to add item:', e);
    }
  };

  const filteredItems = items.filter(item =>
    item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.sku?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalValue = items.reduce((sum, item) => sum + (item.quantity * item.unit_cost), 0);
  const criticalItems = lowStockItems.length;

  return (
    <div className="inventory-dashboard">
      <h2 style={{ marginBottom: '24px' }}>📦 Inventory Management</h2>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px', marginBottom: '32px' }}>
        <StatCard 
          icon="📦" 
          label="Total Items" 
          value={items.length}
        />
        <StatCard 
          icon="💰" 
          label="Total Value" 
          value={`$${totalValue.toFixed(2)}`}
        />
        <StatCard 
          icon="⚠️" 
          label="Low Stock" 
          value={criticalItems}
          color="red"
        />
      </div>

      {/* Low Stock Alert */}
      {lowStockItems.length > 0 && (
        <div style={{
          background: 'rgba(239, 68, 68, 0.1)',
          border: '2px solid var(--red)',
          borderRadius: 'var(--radius)',
          padding: '16px',
          marginBottom: '24px'
        }}>
          <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
            <AlertTriangle size={20} style={{ color: 'var(--red)', flexShrink: 0 }} />
            <div>
              <strong style={{ color: 'var(--red)' }}>Low Stock Alert</strong>
              <div style={{ fontSize: '12px', color: 'var(--muted)', marginTop: '4px' }}>
                {lowStockItems.length} items below reorder level
              </div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '8px' }}>
            {lowStockItems.slice(0, 5).map((item) => (
              <div key={item.id} style={{
                background: 'var(--bg2)',
                padding: '10px 12px',
                borderRadius: '6px',
                fontSize: '12px'
              }}>
                <div style={{ fontWeight: '600' }}>{item.name}</div>
                <div style={{ color: 'var(--muted)', fontSize: '11px', marginTop: '4px' }}>
                  {item.quantity} / {item.reorder_level} units
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Controls */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '20px', flexWrap: 'wrap' }}>
        <div style={{ flex: 1, minWidth: '200px', position: 'relative' }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '12px', opacity: 0.5 }} />
          <input
            type="text"
            className="input"
            placeholder="Search by name or SKU..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ paddingLeft: '36px' }}
          />
        </div>
        <button className="btn btn-primary" onClick={() => setShowAddItem(true)}>
          <Plus size={16} /> Add Item
        </button>
      </div>

      {/* Add Item Form */}
      {showAddItem && (
        <div style={{
          background: 'var(--bg2)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius)',
          padding: '20px',
          marginBottom: '20px'
        }}>
          <form onSubmit={addItem}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '16px' }}>
              <div>
                <label className="label">SKU</label>
                <input
                  type="text"
                  className="input"
                  value={formData.sku}
                  onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                  placeholder="Item SKU"
                />
              </div>
              <div>
                <label className="label">Item Name</label>
                <input
                  type="text"
                  className="input"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Item name"
                  required
                />
              </div>
              <div>
                <label className="label">Quantity</label>
                <input
                  type="number"
                  className="input"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                  placeholder="0"
                />
              </div>
              <div>
                <label className="label">Unit Cost</label>
                <input
                  type="number"
                  className="input"
                  value={formData.unit_cost}
                  onChange={(e) => setFormData({ ...formData, unit_cost: parseFloat(e.target.value) })}
                  placeholder="0.00"
                  step="0.01"
                />
              </div>
              <div>
                <label className="label">Reorder Level</label>
                <input
                  type="number"
                  className="input"
                  value={formData.reorder_level}
                  onChange={(e) => setFormData({ ...formData, reorder_level: parseInt(e.target.value) })}
                  placeholder="10"
                />
              </div>
              <div>
                <label className="label">Supplier</label>
                <input
                  type="text"
                  className="input"
                  value={formData.supplier}
                  onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                  placeholder="Supplier name"
                />
              </div>
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button type="submit" className="btn btn-primary">Save Item</button>
              <button type="button" className="btn btn-ghost" onClick={() => setShowAddItem(false)}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Items Table */}
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>SKU</th>
              <th>Item Name</th>
              <th>Quantity</th>
              <th>Unit Cost</th>
              <th>Total Value</th>
              <th>Reorder Level</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredItems.map((item) => {
              const isLow = item.quantity <= item.reorder_level;
              const itemValue = item.quantity * item.unit_cost;
              return (
                <tr key={item.id} style={{ background: isLow ? 'rgba(239, 68, 68, 0.05)' : 'transparent' }}>
                  <td><strong>{item.sku || 'N/A'}</strong></td>
                  <td>{item.name}</td>
                  <td>{item.quantity}</td>
                  <td>${item.unit_cost.toFixed(2)}</td>
                  <td>${itemValue.toFixed(2)}</td>
                  <td>{item.reorder_level}</td>
                  <td>
                    <span style={{
                      color: isLow ? 'var(--red)' : 'var(--green)',
                      fontWeight: '600',
                      fontSize: '12px'
                    }}>
                      {isLow ? '⚠️ LOW' : '✓ OK'}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-sm btn-ghost" title="Edit">
                      <Edit2 size={14} />
                    </button>
                    <button className="btn btn-sm btn-ghost" title="Delete">
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <style>{`
        .inventory-dashboard { padding: 20px; }

        table {
          border-collapse: collapse;
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          overflow: hidden;
        }

        th {
          background: var(--bg3);
          padding: 12px;
          text-align: left;
          font-weight: 600;
          font-size: 12px;
          text-transform: uppercase;
          border-bottom: 1px solid var(--border);
        }

        td {
          padding: 12px;
          border-bottom: 1px solid var(--border);
          font-size: 13px;
        }

        tr:hover {
          background: var(--bg3);
        }
      `}</style>
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  const colors = { red: '#ef4444', default: '#00d4ff' };
  return (
    <div style={{
      background: 'var(--bg2)',
      border: `1px solid ${color === 'red' ? 'rgba(239, 68, 68, 0.3)' : 'var(--border)'}`,
      borderRadius: 'var(--radius)',
      padding: '16px',
      textAlign: 'center'
    }}>
      <div style={{ fontSize: '24px', marginBottom: '8px' }}>{icon}</div>
      <div style={{ fontSize: '26px', fontWeight: '800', color: color === 'red' ? '#ef4444' : '#00d4ff', marginBottom: '4px' }}>
        {value}
      </div>
      <div style={{ fontSize: '12px', color: 'var(--muted)', textTransform: 'uppercase' }}>
        {label}
      </div>
    </div>
  );
}
