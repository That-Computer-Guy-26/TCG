import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, DollarSign, Users } from 'lucide-react';

export default function ReportsDashboard({ apiBase }) {
  const [performanceReport, setPerformanceReport] = useState(null);
  const [salesReport, setSalesReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [dateRange, setDateRange] = useState('all');

  useEffect(() => {
    loadReports();
  }, [dateRange]);

  const loadReports = async () => {
    setLoading(true);
    try {
      const now = new Date();
      const startDate = dateRange === 'month' 
        ? new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]
        : dateRange === 'quarter'
        ? new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1).toISOString().split('T')[0]
        : '2020-01-01';

      const perfRes = await fetch(`${apiBase}/api/reports/performance`);
      const perfData = await perfRes.json();
      setPerformanceReport(perfData);

      const salesRes = await fetch(`${apiBase}/api/reports/sales?start_date=${startDate}`);
      const salesData = await salesRes.json();
      setSalesReport(salesData);
    } catch (e) {
      console.error('Failed to load reports:', e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="reports-dashboard">
      <h2 style={{ marginBottom: '24px' }}>📊 Reports & Analytics</h2>

      {/* Date Range Filter */}
      <div style={{ marginBottom: '24px' }}>
        <label className="label">Period</label>
        <div style={{ display: 'flex', gap: '8px' }}>
          {['all', 'month', 'quarter'].map((range) => (
            <button
              key={range}
              className={`btn ${dateRange === range ? 'btn-primary' : 'btn-ghost'} btn-sm`}
              onClick={() => setDateRange(range)}
            >
              {range === 'all' ? 'All Time' : range.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Performance Metrics */}
      {performanceReport && (
        <div style={{ marginBottom: '32px' }}>
          <h3 style={{ marginBottom: '16px', fontSize: '18px' }}>Key Performance Indicators</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
            <MetricCard
              icon="👥"
              label="Total Customers"
              value={performanceReport.total_customers}
            />
            <MetricCard
              icon="📅"
              label="Total Appointments"
              value={performanceReport.total_appointments}
            />
            <MetricCard
              icon="✅"
              label="Completed"
              value={performanceReport.completed_appointments}
              subtitle={performanceReport.appointment_completion_rate}
            />
            <MetricCard
              icon="💰"
              label="Total Revenue"
              value={`$${performanceReport.total_revenue}`}
            />
            <MetricCard
              icon="📈"
              label="Avg Customer Value"
              value={`$${performanceReport.average_customer_value}`}
            />
          </div>
        </div>
      )}

      {/* Sales Report */}
      {salesReport && (
        <div style={{ marginBottom: '32px' }}>
          <h3 style={{ marginBottom: '16px', fontSize: '18px' }}>Sales Summary</h3>
          <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '20px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px' }}>
              <SalesMetric
                label="Total Revenue"
                value={`$${salesReport.total_revenue}`}
                change="+12.5%"
              />
              <SalesMetric
                label="Total Invoices"
                value={salesReport.total_invoices}
                change="+8.2%"
              />
              <SalesMetric
                label="Average Invoice"
                value={`$${salesReport.average_invoice}`}
                change="+3.1%"
              />
            </div>
          </div>
        </div>
      )}

      {/* Recent Activity Chart */}
      <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '20px' }}>
        <h3 style={{ marginBottom: '16px', fontSize: '16px' }}>Activity Overview</h3>
        <div style={{ height: '200px', display: 'flex', alignItems: 'flex-end', gap: '4px', padding: '20px 0' }}>
          {[65, 45, 72, 54, 68, 78, 55].map((height, i) => (
            <div
              key={i}
              style={{
                flex: 1,
                height: `${height * 2}px`,
                background: 'linear-gradient(180deg, var(--cyan) 0%, var(--blue) 100%)',
                borderRadius: '4px 4px 0 0',
                opacity: 0.8,
                cursor: 'pointer'
              }}
              title={`Day ${i + 1}: ${height} activities`}
            />
          ))}
        </div>
        <div style={{ fontSize: '12px', color: 'var(--muted)', textAlign: 'center' }}>
          Last 7 days activity
        </div>
      </div>

      <style>{`
        .reports-dashboard { padding: 20px; }
      `}</style>
    </div>
  );
}

function MetricCard({ icon, label, value, subtitle }) {
  return (
    <div style={{
      background: 'var(--bg2)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius)',
      padding: '16px',
      textAlign: 'center'
    }}>
      <div style={{ fontSize: '28px', marginBottom: '8px' }}>{icon}</div>
      <div style={{ fontSize: '24px', fontWeight: '800', color: 'var(--cyan)', marginBottom: '4px' }}>
        {value}
      </div>
      <div style={{ fontSize: '12px', color: 'var(--muted)', textTransform: 'uppercase' }}>
        {label}
      </div>
      {subtitle && (
        <div style={{ fontSize: '11px', color: 'var(--green)', marginTop: '8px', fontWeight: '600' }}>
          {subtitle}
        </div>
      )}
    </div>
  );
}

function SalesMetric({ label, value, change }) {
  return (
    <div>
      <div style={{ fontSize: '12px', color: 'var(--muted)', marginBottom: '4px', textTransform: 'uppercase' }}>
        {label}
      </div>
      <div style={{ fontSize: '24px', fontWeight: '800', color: 'var(--cyan)', marginBottom: '4px' }}>
        {value}
      </div>
      <div style={{ fontSize: '11px', color: 'var(--green)', fontWeight: '600' }}>
        {change}
      </div>
    </div>
  );
}
