import React, { useState } from 'react';
import { Calendar, Clock, MapPin, AlertCircle, CheckCircle } from 'lucide-react';

export default function BookingForm({ apiBase }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    date: '',
    time: '',
    device_type: '',
    urgency: 'normal',
    address: '',
    service_type: 'remote',
    message: '',
    nonprofit: false,
    promo_code: ''
  });

  const [status, setStatus] = useState(null); // 'loading', 'success', 'error'
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('loading');

    try {
      const response = await fetch(`${apiBase}/api/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          type: 'booking'
        })
      });

      const data = await response.json();
      if (data.error) {
        setStatus('error');
        setMessage(data.error);
      } else {
        setStatus('success');
        setMessage(data.message);
        setFormData({
          name: '',
          email: '',
          phone: '',
          service: '',
          date: '',
          time: '',
          device_type: '',
          urgency: 'normal',
          address: '',
          service_type: 'remote',
          message: '',
          nonprofit: false,
          promo_code: ''
        });
      }
    } catch (error) {
      setStatus('error');
      setMessage(`Error: ${error.message}`);
    }

    setTimeout(() => setStatus(null), 5000);
  };

  return (
    <div className="booking-form-section">
      <div className="container" style={{ maxWidth: '700px' }}>
        <h1 className="page-title">Book a Service</h1>
        <p className="page-subtitle">Schedule an appointment with Gary</p>

        <form onSubmit={handleSubmit} className="booking-form">
          {status === 'success' && (
            <div className="success-message">
              <CheckCircle size={20} />
              <p>{message}</p>
            </div>
          )}

          {status === 'error' && (
            <div className="error-message">
              <AlertCircle size={20} />
              <p>{message}</p>
            </div>
          )}

          <div className="form-row">
            <div className="form-group">
              <label className="label">Full Name *</label>
              <input
                type="text"
                className="input"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Your full name"
              />
            </div>

            <div className="form-group">
              <label className="label">Email *</label>
              <input
                type="email"
                className="input"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="your@email.com"
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="label">Phone *</label>
              <input
                type="tel"
                className="input"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                placeholder="(812) 555-0000"
              />
            </div>

            <div className="form-group">
              <label className="label">Service Type *</label>
              <select className="input" name="service_type" value={formData.service_type} onChange={handleChange}>
                <option value="remote">Remote Support</option>
                <option value="onsite">On-Site Service</option>
              </select>
            </div>
          </div>

          {formData.service_type === 'onsite' && (
            <div className="form-group">
              <label className="label">Address</label>
              <input
                type="text"
                className="input"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="Service location address"
              />
            </div>
          )}

          <div className="form-row">
            <div className="form-group">
              <label className="label">Service Category *</label>
              <select className="input" name="service" value={formData.service} onChange={handleChange} required>
                <option value="">Select a service</option>
                <option value="Computer Repair">Computer Repair</option>
                <option value="Networking">Networking</option>
                <option value="Software">Software</option>
                <option value="AI & Automation">AI & Automation</option>
                <option value="Web Development">Web Development</option>
                <option value="Security">Security</option>
                <option value="Data Services">Data Services</option>
                <option value="Mobile & Devices">Mobile & Devices</option>
                <option value="Business Solutions">Business Solutions</option>
                <option value="Cloud Services">Cloud Services</option>
              </select>
            </div>

            <div className="form-group">
              <label className="label">Device Type</label>
              <select className="input" name="device_type" value={formData.device_type} onChange={handleChange}>
                <option value="">Select if applicable</option>
                <option value="desktop">Desktop Computer</option>
                <option value="laptop">Laptop</option>
                <option value="phone">Phone</option>
                <option value="tablet">Tablet</option>
                <option value="network">Network Equipment</option>
                <option value="server">Server</option>
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="label">Preferred Date</label>
              <input
                type="date"
                className="input"
                name="date"
                value={formData.date}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="label">Preferred Time</label>
              <input
                type="time"
                className="input"
                name="time"
                value={formData.time}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="label">Urgency</label>
              <select className="input" name="urgency" value={formData.urgency} onChange={handleChange}>
                <option value="normal">Normal</option>
                <option value="high">High</option>
                <option value="emergency">Emergency (24/7)</option>
              </select>
            </div>

            <div className="form-group">
              <label className="label">Promo Code</label>
              <input
                type="text"
                className="input"
                name="promo_code"
                value={formData.promo_code}
                onChange={handleChange}
                placeholder="e.g., TCG26FREE"
              />
            </div>
          </div>

          <div className="form-group">
            <label className="label">Additional Details</label>
            <textarea
              className="input"
              name="message"
              value={formData.message}
              onChange={handleChange}
              placeholder="Describe your issue or what you need help with..."
              style={{ minHeight: '120px' }}
            />
          </div>

          <div className="form-group checkbox">
            <input
              type="checkbox"
              id="nonprofit"
              name="nonprofit"
              checked={formData.nonprofit}
              onChange={handleChange}
            />
            <label htmlFor="nonprofit">
              I represent a qualifying nonprofit organization (eligible for free services)
            </label>
          </div>

          <button
            type="submit"
            disabled={status === 'loading'}
            className="btn btn-primary btn-lg btn-full"
            style={{ marginTop: '12px' }}
          >
            {status === 'loading' ? 'Booking...' : 'Book Appointment'}
          </button>
        </form>

        <div className="booking-info">
          <h3>📞 Prefer to Call?</h3>
          <p>Gary is available 24/7</p>
          <p style={{ fontSize: '18px', fontWeight: '700', color: 'var(--cyan)' }}>(812) 373-6023</p>
        </div>
      </div>

      <style>{`
        .booking-form-section {
          padding: 40px 20px;
        }

        .page-title {
          font-size: 36px;
          font-weight: 900;
          text-align: center;
          margin-bottom: 12px;
        }

        .page-subtitle {
          font-size: 16px;
          color: var(--muted);
          text-align: center;
          margin-bottom: 40px;
        }

        .booking-form {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 32px;
          margin-bottom: 32px;
        }

        .form-row {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
          margin-bottom: 16px;
        }

        .form-group {
          display: flex;
          flex-direction: column;
        }

        .form-group.checkbox {
          flex-direction: row;
          align-items: center;
          gap: 8px;
          margin-top: 8px;
        }

        .form-group.checkbox input[type="checkbox"] {
          width: auto;
          cursor: pointer;
        }

        .form-group.checkbox label {
          margin: 0;
          font-size: 13px;
          color: var(--muted);
          cursor: pointer;
        }

        .btn-full {
          width: 100%;
        }

        .success-message,
        .error-message {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 16px;
          border-radius: var(--radius);
          margin-bottom: 20px;
          font-size: 14px;
        }

        .success-message {
          background: rgba(34, 197, 94, 0.15);
          border: 1px solid rgba(34, 197, 94, 0.3);
          color: var(--green);
        }

        .error-message {
          background: rgba(239, 68, 68, 0.15);
          border: 1px solid rgba(239, 68, 68, 0.3);
          color: var(--red);
        }

        .booking-info {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 32px;
          text-align: center;
        }

        .booking-info h3 {
          margin-bottom: 8px;
          font-size: 18px;
        }

        .booking-info p {
          color: var(--muted);
          margin-bottom: 4px;
        }

        @media (max-width: 768px) {
          .form-row {
            grid-template-columns: 1fr;
          }

          .booking-form {
            padding: 20px;
          }

          .page-title {
            font-size: 24px;
          }
        }
      `}</style>
    </div>
  );
}
