import React, { useState, useEffect } from 'react';
import { Calendar, Clock, User, MapPin, Phone } from 'lucide-react';

export default function SchedulingDashboard({ apiBase }) {
  const [appointments, setAppointments] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadAppointments();
  }, [selectedDate]);

  const loadAppointments = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/api/calendar?start_date=${selectedDate}&end_date=${selectedDate}`);
      const data = await res.json();
      setAppointments(data.appointments || []);
    } catch (e) {
      console.error('Failed to load appointments:', e);
    } finally {
      setLoading(false);
    }
  };

  const dayAppointments = appointments.filter(apt => apt.date === selectedDate).sort((a, b) => a.time.localeCompare(b.time));

  const stats = {
    total: appointments.length,
    today: dayAppointments.length,
    upcoming: appointments.filter(apt => new Date(`${apt.date}T${apt.time}`) > new Date()).length
  };

  return (
    <div className="scheduling-dashboard">
      <h2 style={{ marginBottom: '24px' }}>📅 Appointment Scheduling</h2>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px', marginBottom: '32px' }}>
        <StatCard label="Total Appointments" value={stats.total} icon="📋" />
        <StatCard label="Today" value={stats.today} icon="📅" />
        <StatCard label="Upcoming" value={stats.upcoming} icon="⏰" />
      </div>

      {/* Date Picker */}
      <div style={{ marginBottom: '24px' }}>
        <label className="label">Select Date</label>
        <input
          type="date"
          className="input"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          style={{ maxWidth: '200px' }}
        />
      </div>

      {/* Appointments List */}
      <div style={{ display: 'grid', gap: '12px' }}>
        {dayAppointments.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--muted)' }}>
            No appointments scheduled for {new Date(selectedDate).toLocaleDateString()}
          </div>
        ) : (
          dayAppointments.map((apt) => (
            <div key={apt.id} className="appointment-card">
              <div style={{ display: 'flex', gap: '12px' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                    <Clock size={16} />
                    <strong>{apt.time}</strong>
                    <span style={{ color: 'var(--muted)', fontSize: '13px' }}>({apt.duration} min)</span>
                  </div>
                  <div style={{ color: 'var(--text)', fontWeight: '600', marginBottom: '4px' }}>
                    {apt.service}
                  </div>
                  {apt.notes && (
                    <div style={{ fontSize: '13px', color: 'var(--muted)', marginTop: '4px' }}>
                      {apt.notes}
                    </div>
                  )}
                </div>
                <div style={{ textAlign: 'right', fontSize: '12px', color: 'var(--muted)' }}>
                  <div style={{ marginBottom: '4px', color: 'var(--cyan)', fontWeight: '600' }}>
                    {apt.status.toUpperCase()}
                  </div>
                  <div>{apt.customer_id}</div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <style>{`
        .scheduling-dashboard { padding: 20px; }
        
        .stat-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 16px;
          text-align: center;
        }

        .appointment-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 16px;
          transition: all 0.2s;
        }

        .appointment-card:hover {
          border-color: rgba(0, 212, 255, 0.5);
          box-shadow: 0 4px 12px rgba(0, 212, 255, 0.1);
        }
      `}</style>
    </div>
  );
}

function StatCard({ label, value, icon }) {
  return (
    <div className="stat-card">
      <div style={{ fontSize: '24px', marginBottom: '8px' }}>{icon}</div>
      <div style={{ fontSize: '28px', fontWeight: '800', color: 'var(--cyan)' }}>{value}</div>
      <div style={{ fontSize: '12px', color: 'var(--muted)', textTransform: 'uppercase', marginTop: '8px' }}>
        {label}
      </div>
    </div>
  );
}
