import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export default function ServicesShowcase() {
  const [expandedCategory, setExpandedCategory] = useState(null);

  const services = {
    'Computer Repair': ['Virus removal', 'OS installation', 'Hardware diagnostics', 'Data recovery', 'SSD upgrades', 'RAM upgrades', 'Screen repair', 'Power supply replacement', 'Performance optimization'],
    'Networking': ['WiFi setup', 'Router configuration', 'Network security', 'VPN setup', 'Firewall configuration', 'IP camera installation', 'NAS setup', 'Network monitoring', 'Wireless survey'],
    'Software': ['Windows repair', 'Office setup', 'Antivirus installation', 'Software updates', 'Email configuration', 'Browser optimization', 'Backup solutions', 'Software troubleshooting', 'Driver management'],
    'AI & Automation': ['ChatGPT setup', 'AI workflow automation', 'Custom AI assistants', 'Business process automation', 'Data analysis AI', 'Document processing', 'Chatbot development', 'Prompt engineering'],
    'Web Development': ['Website development', 'Web app development', 'React/Node apps', 'Database design', 'API integration', 'E-commerce sites', 'Landing pages', 'WordPress sites', 'SEO optimization'],
    'Security': ['Antivirus/anti-malware', 'Firewall setup', 'Security audit', 'Password management', '2FA setup', 'Encryption setup', 'Ransomware protection', 'Phishing protection', 'Security training'],
    'Data Services': ['Data recovery', 'Data backup', 'Data migration', 'Cloud backup', 'Disaster recovery', 'RAID recovery', 'Data archiving', 'Data sanitization', 'Forensic recovery'],
    'Mobile & Devices': ['Phone repair', 'Tablet repair', 'Phone setup', 'Data transfer', 'Phone backup', 'Phone optimization', 'App management', 'Device troubleshooting', 'Accessibility setup'],
    'Business Solutions': ['IT consulting', 'Managed IT', 'Help desk support', 'Business continuity', 'Technology planning', 'Systems integration', 'Business automation', 'Digital transformation'],
    'Cloud Services': ['Microsoft 365 setup', 'Google Workspace setup', 'Cloud migration', 'Cloud storage setup', 'Cloud backup configuration', 'Cloud security', 'Hybrid cloud setup']
  };

  return (
    <div className="services-showcase">
      <div className="container">
        <h1 className="page-title">200+ Services Across 10 Categories</h1>
        <p className="page-subtitle">Complete IT support and AI automation solutions</p>

        <div className="services-grid">
          {Object.entries(services).map(([category, items], idx) => (
            <div
              key={idx}
              className="service-card"
              onClick={() => setExpandedCategory(expandedCategory === idx ? null : idx)}
            >
              <div className="service-header">
                <h3>{category}</h3>
                <ChevronDown
                  size={20}
                  className={`chevron ${expandedCategory === idx ? 'expanded' : ''}`}
                />
              </div>

              {expandedCategory === idx && (
                <div className="service-items">
                  {items.map((item, i) => (
                    <div key={i} className="service-item">
                      <span className="checkmark">✓</span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <style>{`
        .services-showcase {
          padding: 40px 20px;
        }

        .page-title {
          font-size: 36px;
          font-weight: 900;
          text-align: center;
          margin-bottom: 12px;
        }

        .page-subtitle {
          font-size: 16px;
          color: var(--muted);
          text-align: center;
          margin-bottom: 40px;
        }

        .services-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 16px;
        }

        .service-card {
          background: var(--bg2);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 20px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .service-card:hover {
          border-color: rgba(0, 212, 255, 0.3);
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .service-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
        }

        .service-header h3 {
          font-size: 16px;
          margin: 0;
        }

        .chevron {
          transition: transform 0.2s;
          color: var(--cyan);
        }

        .chevron.expanded {
          transform: rotate(180deg);
        }

        .service-items {
          margin-top: 16px;
          padding-top: 16px;
          border-top: 1px solid var(--border);
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .service-item {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          font-size: 13px;
          color: var(--muted);
        }

        .checkmark {
          color: var(--green);
          font-weight: 700;
          flex-shrink: 0;
          margin-top: 1px;
        }

        @media (max-width: 768px) {
          .services-grid {
            grid-template-columns: 1fr;
          }

          .page-title {
            font-size: 24px;
          }
        }
      `}</style>
    </div>
  );
}
