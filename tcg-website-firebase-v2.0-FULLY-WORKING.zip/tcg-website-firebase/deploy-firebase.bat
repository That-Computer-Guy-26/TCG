@echo off
setlocal enabledelayedexpansion

echo.
echo ╔════════════════════════════════════════════════════════════════╗
echo ║                                                                ║
echo ║     🚀 DEPLOYING TO FIREBASE HOSTING & DATABASE 🚀          ║
echo ║                                                                ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.

REM ── STEP 1: CHECK FIREBASE CLI ──
echo [1/4] Checking Firebase CLI...

where firebase >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ Firebase CLI not installed
    echo Install with: npm install -g firebase-tools
    pause
    exit /b 1
)
echo ✓ Firebase CLI found
echo.

REM ── STEP 2: CHECK FRONTEND BUILD ──
echo [2/4] Checking frontend build...

if not exist "dist\" (
    echo Building frontend...
    call npm run build
    echo ✓ Frontend built
) else (
    echo ✓ Frontend already built
)
echo.

REM ── STEP 3: DEPLOY ──
echo [3/4] Deploying to Firebase...
call firebase deploy

if %errorlevel% equ 0 (
    echo.
    echo ╔════════════════════════════════════════════════════════════════╗
    echo ║                  ✅ DEPLOYMENT SUCCESSFUL! ✅                 ║
    echo ╠════════════════════════════════════════════════════════════════╣
    echo ║                                                                ║
    echo ║  Your site is now LIVE!                                        ║
    echo ║                                                                ║
    echo ║  Check your Firebase console to find the hosting URL:          ║
    echo ║  https://console.firebase.google.com                           ║
    echo ║                                                                ║
    echo ║  Or run: firebase open hosting:site                            ║
    echo ║                                                                ║
    echo ╚════════════════════════════════════════════════════════════════╝
) else (
    echo.
    echo ❌ Deployment failed
    pause
    exit /b 1
)

pause
