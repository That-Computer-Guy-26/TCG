#!/bin/bash

# ============================================================
# TCG WEBSITE - FIREBASE DEPLOYMENT SCRIPT
# ============================================================

set -e

echo "
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║     🚀 DEPLOYING TO FIREBASE HOSTING & DATABASE 🚀          ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Check Firebase CLI
echo -e "${BLUE}Step 1: Checking Firebase CLI...${NC}\n"

if ! command -v firebase &> /dev/null; then
    echo -e "${RED}❌ Firebase CLI not installed${NC}"
    echo "Install with: npm install -g firebase-tools"
    exit 1
fi

echo -e "${GREEN}✓ Firebase CLI found${NC}\n"

# Check if logged in
echo -e "${BLUE}Step 2: Checking Firebase login...${NC}\n"

if firebase auth:list 2>/dev/null | grep -q "Logged in as"; then
    echo -e "${GREEN}✓ Logged in to Firebase${NC}\n"
else
    echo -e "${YELLOW}Not logged in. Running firebase login...${NC}\n"
    firebase login
fi

# Build frontend if dist doesn't exist
echo -e "${BLUE}Step 3: Checking frontend build...${NC}\n"

if [ ! -d "dist" ]; then
    echo -e "${YELLOW}Building frontend...${NC}"
    npm run build
    echo -e "${GREEN}✓ Frontend built${NC}\n"
else
    echo -e "${GREEN}✓ Frontend already built${NC}\n"
fi

# Deploy to Firebase
echo -e "${BLUE}Step 4: Deploying to Firebase...${NC}\n"

if firebase deploy; then
    echo ""
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                  ✅ DEPLOYMENT SUCCESSFUL! ✅                 ║"
    echo "╠════════════════════════════════════════════════════════════════╣"
    echo "║                                                                ║"
    echo "║  Your site is now LIVE!                                        ║"
    echo "║                                                                ║"
    echo "║  Check your Firebase console to find the hosting URL:          ║"
    echo "║  https://console.firebase.google.com                           ║"
    echo "║                                                                ║"
    echo "║  Or run: firebase open hosting:site                            ║"
    echo "║                                                                ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
else
    echo -e "${RED}❌ Deployment failed${NC}"
    exit 1
fi
